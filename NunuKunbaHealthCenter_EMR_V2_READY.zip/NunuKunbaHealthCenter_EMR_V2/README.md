# Nunu Kunba Health Center EMR v2.0

Mobile health-center EMR starter for Nunu Kunba Health Center.

Includes patient registration, local patient records, EMR visits, clinical notes, vital signs, diagnosis, laboratory, pharmacy, appointments, referrals, reports and role menu.

Blood Bank is intentionally excluded.
