package com.nunukunba.healthcenter

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

private data class Patient(val id:String,val name:String,val sex:String,val age:String,val phone:String,val insurance:String,val insuranceCode:String)
private data class Visit(val date:String,val complaint:String,val diagnosis:String,val treatment:String,val bp:String,val pulse:String,val temp:String,val lab:String,val medicine:String)

class MainActivity: ComponentActivity(){ override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App(this)}} }

@Composable fun App(ctx:Context){
 var logged by remember{mutableStateOf(false)}
 if(!logged) Login{logged=true} else EMRApp(ctx)
}

@Composable fun Login(onLogin:()->Unit){
 var u by remember{mutableStateOf("")}; var p by remember{mutableStateOf("")}
 Surface(Modifier.fillMaxSize()){Column(Modifier.fillMaxSize().padding(28.dp),verticalArrangement=Arrangement.Center){
  Text("Nunu Kunba Health Center",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Electronic Medical Record (EMR)",style=MaterialTheme.typography.titleMedium)
  Spacer(Modifier.height(24.dp));OutlinedTextField(u,{u=it},label={Text("Username")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(10.dp));OutlinedTextField(p,{p=it},label={Text("Password")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(18.dp));Button(onClick=onLogin,modifier=Modifier.fillMaxWidth()){Text("Login")}
  Spacer(Modifier.height(10.dp));Text("Demo: enter any username and password",style=MaterialTheme.typography.bodySmall)
 }}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun EMRApp(ctx:Context){
 val store=remember{Store(ctx)}; var page by remember{mutableStateOf("Dashboard")}; var selected by remember{mutableStateOf<Patient?>(null)}
 val pages=listOf("Dashboard","Patients","Register","EMR","Laboratory","Pharmacy","Appointments","Referrals","Reports","Users")
 Scaffold(topBar={TopAppBar(title={Text(page)})}){pad->Row(Modifier.fillMaxSize().padding(pad)){NavigationRail{pages.forEach{p->NavigationRailItem(selected=page==p,onClick={page=p},icon={Icon(if(p=="Patients") Icons.Default.Person else if(p=="Register") Icons.Default.PersonAdd else if(p=="EMR") Icons.Default.MedicalServices else if(p=="Laboratory") Icons.Default.Science else if(p=="Pharmacy") Icons.Default.Medication else if(p=="Appointments") Icons.Default.CalendarMonth else if(p=="Referrals") Icons.Default.Send else if(p=="Reports") Icons.Default.BarChart else if(p=="Users") Icons.Default.People else Icons.Default.Dashboard,null)},label={Text(p)} )};}
 Box(Modifier.fillMaxSize().padding(16.dp)){when(page){
 "Dashboard"->Dashboard(store, {page="Register"},{page="Patients"})
 "Patients"->Patients(store){selected=it;page="EMR"}
 "Register"->Register(store){page="Patients"}
 "EMR"->EMR(store,selected)
 "Laboratory"->SimpleModule("Laboratory",listOf("Test Request","Result Entry","CBC","Urinalysis","Malaria Test","HIV/TB follow-up"))
 "Pharmacy"->SimpleModule("Pharmacy",listOf("Prescription","Dispensing","Medicine Stock","Refill / Follow-up"))
 "Appointments"->SimpleModule("Appointments",listOf("New Appointment","Upcoming Visits","Follow-up Schedule"))
 "Referrals"->SimpleModule("Referrals",listOf("Referral-out","Referral-in","Counter-referral","Referral Tracking"))
 "Reports"->SimpleModule("HMIS / Reports",listOf("Daily Service Report","Monthly Report","Patient Statistics","OPD Statistics","Maternal & Child Health","Laboratory Statistics"))
 "Users"->SimpleModule("Users & Roles",listOf("Admin","Clinician / Doctor","Nurse / Midwife","Laboratory","Pharmacy","HMIS Officer"))
 }} }}
}

@Composable fun Dashboard(store:Store,register:()->Unit,patients:()->Unit){val ps=store.patients();LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("Welcome to Nunu Kunba Health Center",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)};item{Text("EMR Version 2.0 — patient records, clinical care and reports")};item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Card(Modifier.weight(1f)){Column(Modifier.padding(14.dp)){Text("Patients");Text(ps.size.toString(),style=MaterialTheme.typography.headlineMedium)}};Card(Modifier.weight(1f)){Column(Modifier.padding(14.dp)){Text("Visits");Text("EMR",style=MaterialTheme.typography.titleLarge)}}}};item{Button(register,Modifier.fillMaxWidth()){Icon(Icons.Default.PersonAdd,null);Spacer(Modifier.width(6.dp));Text("Register Patient")}};item{OutlinedButton(patients,Modifier.fillMaxWidth()){Text("Open Patient List")}}}}

@Composable fun Patients(store:Store,onSelect:(Patient)->Unit){val ps=store.patients();Column{Text("Registered Patients",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));if(ps.isEmpty())Text("No patients registered yet.") else LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(ps){p->Card(onClick={onSelect(p)},modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(p.name,fontWeight=FontWeight.Bold);Text("ID: ${p.id}  •  ${p.sex}  •  Age ${p.age}");Text("Insurance: ${p.insurance} / ${p.insuranceCode}")}}}}}}

@Composable fun Register(store:Store,done:()->Unit){var id by remember{mutableStateOf("NK-${System.currentTimeMillis()%100000}")};var n by remember{mutableStateOf("")};var sex by remember{mutableStateOf("Female")};var age by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var ins by remember{mutableStateOf("CBHI")};var code by remember{mutableStateOf("")};LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)){item{Text("Patient Registration",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)};item{OutlinedTextField(id,{id=it},label={Text("Patient ID")},modifier=Modifier.fillMaxWidth())};item{OutlinedTextField(n,{n=it},label={Text("Full Name")},modifier=Modifier.fillMaxWidth())};item{OutlinedTextField(sex,{sex=it},label={Text("Sex")},modifier=Modifier.fillMaxWidth())};item{OutlinedTextField(age,{age=it},label={Text("Age")},modifier=Modifier.fillMaxWidth())};item{OutlinedTextField(phone,{phone=it},label={Text("Phone")},modifier=Modifier.fillMaxWidth())};item{OutlinedTextField(ins,{ins=it},label={Text("Insurance Type")},modifier=Modifier.fillMaxWidth())};item{OutlinedTextField(code,{code=it},label={Text("Insurance Code")},modifier=Modifier.fillMaxWidth())};item{Button(onClick={if(n.isNotBlank()){store.add(Patient(id,n,sex,age,phone,ins,code));done()}},modifier=Modifier.fillMaxWidth()){Text("Save Patient")}}}}

@Composable fun EMR(store:Store,selected:Patient?){var complaint by remember{mutableStateOf("")};var diagnosis by remember{mutableStateOf("")};var treatment by remember{mutableStateOf("")};var bp by remember{mutableStateOf("")};var pulse by remember{mutableStateOf("")};var temp by remember{mutableStateOf("")};var lab by remember{mutableStateOf("")};var med by remember{mutableStateOf("")};LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)){item{Text(if(selected==null)"EMR Visit" else "EMR: ${selected.name}",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)};item{Text("Clinical note, vital signs, diagnosis, laboratory and medication record")};listOf("Chief Complaint" to complaint,"Diagnosis" to diagnosis,"Treatment / Plan" to treatment,"Blood Pressure" to bp,"Pulse" to pulse,"Temperature" to temp,"Laboratory Result" to lab,"Medication / Prescription" to med).forEach{(label,value)->item{OutlinedTextField(value,{v->when(label){"Chief Complaint"->complaint=v;"Diagnosis"->diagnosis=v;"Treatment / Plan"->treatment=v;"Blood Pressure"->bp=v;"Pulse"->pulse=v;"Temperature"->temp=v;"Laboratory Result"->lab=v;"Medication / Prescription"->med=v}},label={Text(label)},modifier=Modifier.fillMaxWidth())}};item{Button(onClick={selected?.let{store.addVisit(it.id,Visit("Today",complaint,diagnosis,treatment,bp,pulse,temp,lab,med))}},modifier=Modifier.fillMaxWidth()){Text("Save EMR Visit")}};item{selected?.let{Text("Patient history is stored on this device and can be reviewed from the patient record.",style=MaterialTheme.typography.bodySmall)}}}}

@Composable fun SimpleModule(title:String,items:List<String>){LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text(title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)};items.forEach{x->item{Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.CheckCircle,null);Spacer(Modifier.width(10.dp));Text(x)}}}}}}

class Store(private val ctx:Context){private val sp=ctx.getSharedPreferences("emr",0);fun patients():List<Patient>{val a=JSONArray(sp.getString("patients","[]"));return (0 until a.length()).map{val o=a.getJSONObject(it);Patient(o.getString("id"),o.getString("name"),o.getString("sex"),o.getString("age"),o.getString("phone"),o.getString("insurance"),o.getString("insuranceCode"))}};fun add(p:Patient){val a=JSONArray(sp.getString("patients","[]"));a.put(JSONObject().apply{put("id",p.id);put("name",p.name);put("sex",p.sex);put("age",p.age);put("phone",p.phone);put("insurance",p.insurance);put("insuranceCode",p.insuranceCode)});sp.edit().putString("patients",a.toString()).apply()};fun addVisit(id:String,v:Visit){val key="visits_$id";val a=JSONArray(sp.getString(key,"[]"));a.put(JSONObject().apply{put("date",v.date);put("complaint",v.complaint);put("diagnosis",v.diagnosis);put("treatment",v.treatment);put("bp",v.bp);put("pulse",v.pulse);put("temp",v.temp);put("lab",v.lab);put("medicine",v.medicine)});sp.edit().putString(key,a.toString()).apply()}}
