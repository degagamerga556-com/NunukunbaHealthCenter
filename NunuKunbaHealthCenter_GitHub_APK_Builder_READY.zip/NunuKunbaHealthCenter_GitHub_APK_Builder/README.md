# Nunu Kunba Health Center Android App

Starter Android app for Nunu Kunba Health Center.

Included in this version:
- Staff Login (demo)
- Dashboard
- Patient Registration
- Insurance Type
- Insurance Code

Blood Bank is intentionally excluded.

## Build APK on GitHub
1. Upload the contents of this project to the repository root.
2. Open the **Actions** tab.
3. Select **Build Android APK**.
4. Click **Run workflow**.
5. When it finishes, open the workflow run and download the artifact named `Nunu-Kunba-Health-Center-APK`.
