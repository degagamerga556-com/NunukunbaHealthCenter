package com.nunukunba.healthcenter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NunuKunbaApp() }
    }
}

@Composable
fun NunuKunbaApp() {
    var loggedIn by remember { mutableStateOf(false) }
    var showRegistration by remember { mutableStateOf(false) }
    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            when {
                !loggedIn -> LoginScreen { loggedIn = true }
                showRegistration -> PatientRegistrationScreen { showRegistration = false }
                else -> DashboardScreen { showRegistration = true }
            }
        }
    }
}

@Composable
fun LoginScreen(onLogin: () -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Nunu Kunba Health Center", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text("Staff Login")
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(username, { username = it }, label = { Text("Username") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(password, { password = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(20.dp))
        Button(onClick = onLogin, modifier = Modifier.fillMaxWidth()) { Text("Login") }
        Spacer(Modifier.height(8.dp))
        Text("Demo version: any username/password can continue.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun DashboardScreen(onRegister: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        Text("Dashboard", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text("Nunu Kunba Health Center")
        Spacer(Modifier.height(24.dp))
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text("Patient Management", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Text("Register patients and record insurance information.")
                Spacer(Modifier.height(14.dp))
                Button(onClick = onRegister) { Text("Patient Registration") }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Patient List: available in the next version.")
    }
}

@Composable
fun PatientRegistrationScreen(onBack: () -> Unit) {
    var patientId by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var sex by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var insuranceType by remember { mutableStateOf("") }
    var insuranceCode by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)
    ) {
        Text("Patient Registration", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        Field("Patient ID", patientId) { patientId = it }
        Field("Full Name", fullName) { fullName = it }
        Field("Sex", sex) { sex = it }
        Field("Age", age) { age = it }
        Field("Phone Number", phone) { phone = it }
        Field("Insurance Type", insuranceType) { insuranceType = it }
        Field("Insurance Code", insuranceCode) { insuranceCode = it }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { saved = true }) { Text("Save Patient") }
            OutlinedButton(onClick = onBack) { Text("Back") }
        }
        if (saved) {
            Spacer(Modifier.height(12.dp))
            Text("Patient saved successfully (demo).", color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun Field(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
    )
}
